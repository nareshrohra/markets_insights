Version 1

Copyright (C) 2024, Naresh Rohra

The code in this repository is owned by NARESH ROHRA. This code or part of it cannot be used in any commercial software or application without explicit permission from the owner.
